# Lab 7 William yu, Erik Lagman, Ethan Newtown

sports_leagues = {
    "NFL": "National Football League",
    "MLB": "Major League Baseball",
    "NBA": "National Basketball Association",
    "EPL": "Premier League",
    "NHL": "National Hockey League",
    "MLS": "Major League Soccer",
    "IPL": "Indian Premier League",
    "AFL": "Australian Football League",
    "NRL": "National Rugby League",
    "CFL": "Canadian Football League"
}


def delete_league():
    """
    Delete one of the leagues in the dictionary
    :return: Informs user the league has been removed 
    """
    global sports_leagues

    user_league = str(input("Please choose a league to delete:"))

    if user_league.upper() in sports_leagues:
        print("The", sports_leagues.pop(user_league.upper()), "has been removed")
    else:
        print("There is no league named", user_league)


def add_league():
    """
    Add a sports league to the current sports league list
    :return: Sports league list with new sports league in full string description
    """

    global sports_leagues
    additional = str(input("Please enter a new league's three letter abbreviation:")).upper()
    additional2 = str(input("Please enter the new leagues description:")).title()
    if additional not in sports_leagues:
        new_league = {}
        new_league.update({additional: additional2})
        sports_leagues.update(new_league)
        print(new_league, "has been added to the leagues")
    else:
        print(additional, "is already listed as", sports_leagues[additional])


def get_abbreviations():
    """
    Creates a list of sports leagues key values
    :return: list of key values from sports leagues
    """

    return list(sports_leagues.keys())


def get_league_descriptions_tuple():
    """
    Returns a tuple of the sports leagues values
    :return: tuple of sports leagues
    """

    return tuple(sports_leagues.values())


def get_league_descriptions_set():
    """
    Creates and return a set of sports leagues keys and values
    :return: keys and values of sports league in random order
    """

    global sports_leagues
    k = set(sports_leagues.keys())
    v = set(sports_leagues.values())
    k.update(v)

    return k


def main():
    delete_league()
    add_league()
    print(get_abbreviations())
    print(get_league_descriptions_tuple())
    print(get_league_descriptions_set())


if __name__ == "__main__":
    main()
