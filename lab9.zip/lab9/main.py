# Lab 9
# William Yu, Ethan Newtown, Erik Lagman

import re


def is_valid_license_plate(plate_number):
    """
    License plate number with six characters total: three letters then three digits, or three digits then three letters,
    or  two letters, digit, space or hyphen, two digits, letter and all letters are UPPERCASE
    :param plate_number: 6 characters all uppercase
    :return:  true or false
    """

    if re.search(r"^[A-Z]{3}[0-9]{3}|[0-9]{3}[A-Z]{3}|[A-Z0-9]{3}[ -][A-Z0-9]{3}",  plate_number):
        print("Valid plate")
        return True
    else:
        print("Invalid plate")
        return False


def is_valid_python_variable_name(variables):
    """
    Between one and 32 characters total: all characters must be lowercase letters or underscores, but not more than one
    underscore in a row
    :param variables: 1 to 32 characters lowercase no consecutive underscores
    :return: true or false
    """

    if re.search(r"^[_a-z0-9]{1,32}$", variables) and not re.search(r"__", variables):
        print("Valid parameters")
        return True
    else:
        print("No good bruh")
        return False


def is_valid_email_address(email):
    """
    Username rules: letters (upper or lower case) and underscores (as long as _ is neither the first nor last
    character): between 1 and 256 characters total
    Domain name rules: letters (upper or lowercase) between 1 and 32 characters total
    Top-level-domain rules: letters (upper or lower case) between 2 and 5 characters total.
    :param email: 1 to 256 characters in username, 1 to 32 characters in domain name, top domain must be 2-5 characters
    :return: true or false
    """

    if re.match(r"^[a-zA-Z][_?a-zA-Z]{1,256}[a-zA-Z]@[a-zA-Z]{1,32}.[a-zA-Z]{2,5}$", email):
        print("Valid Email")
        return True
    else:
        print("Invalid Username")
        return False


def is_valid_human_height(height):
    """
    Number of feet, apostrophe, number of inches, double quotation mark. The number of feet must be 2-8 inclusive.
    The number of inches must be 0-11 inclusive.
    The number of inches between 0 and 9 may have an optional leading zero (e.g. 5’08” or5’8”)
    The shortest height is 2’1” (not 2’0”) and the tallest height is 8’11
    Inches maybe used instead of quotation marks
    :param height: Between 2'1" and 8"11
    :return:
    """

    if re.search(r"^[2-8]'(0?[1-9])(\"|in)|[2-8]'(1[0-1](\"|in))$", height):
        print("Good Height")
        return True
    else:
        print("Too tall or too short ")
        return False


def main():
    is_valid_license_plate("ABC123")
    is_valid_python_variable_name("this_is_a_good_name")
    is_valid_email_address("solid_email___right_here@gmail.com")
    is_valid_human_height("5'09")


if __name__ == '__main__':
    main()
