# Assignment 3 William Yu


from data import countries_and_capitals
from country import Country
import random


def main():
    """The main function try’s to create a list of Country objects called all_countries
    (assigning each one a random population between 1 million and 1 billion, in the try
    block) using the countries_and_capitals tuple (use a loop); make sure any
    ValueError exceptions are handled by printing “oops” to the console in addition to
    the ValueError’s message of “Population 1057988 is too low”."""
    try:
        all_countries = []
        for country in countries_and_capitals:
            all_countries.append(Country(country[0], country[1], random.randint(1000000, 1000000000)))

    except ValueError as e:
        print(f"oops {e}")

    else:
        print("Loop 1")
        for country in all_countries:
            country.print_details()
        print("Loop 2")
        for country in all_countries:
            country.birth()
            country.print_details()
        print("Loop 3")
        for country in all_countries:
            country.death()
            country.print_details()
        print("Loop 4")
        for country in all_countries:
            country.disaster()
            country.print_details()


if __name__ == "__main__":
    main()
