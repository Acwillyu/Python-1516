# Assignment 3

class Country:
    """ Define a constructor that takes three parameters: a country name, a capital name, and a population.
    In the constructor, assign the parameter values to the instance variables, unless the population is less
    than 2 million; in that case raise a ValueError with a message in the format of
    (“Population 1057988 is too low”)."""
    def __init__(self, country, capital, population):
        self.country = country
        self.capital = capital
        self.population = population
        if self.population <= 2000000:
            raise ValueError(f"Population {population} is too low")

    def print_details(self):
        """
        Prints the details of the country, capital and population
        :return: no return
        """
        stats = f"The capital of {self.country} (pop. of {self.population}) is {self.capital}"
        print(stats)

    def birth(self):
        """
        adds 1 to country's population
        :return: no return
        """
        self.population += 1

    def death(self):
        """
        Subtracts 1 from country's population
        :return: no return
        """
        self.population -= 1

    def disaster(self):
        """
        For countries with a population of 100 million or higher, this method subtracts 100 million from the population.
        For smaller countries, it sets the population to 0
        :return:
        """
        if self.population >= 100000000:
            self.population -= 100000000
        else:
            self.population = 0
