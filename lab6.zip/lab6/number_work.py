# Lab 6 William yu, Erik Lagman, Ethan Newtown


def get_square_numbers_between(first, last):
    """
    Finding the square numbers from the range of two numbers
    :return: all square numbers including the first and last numbers
    """
    sq_number = []
    index = 0
    while True:
        sq = index ** 2
        index += 1
        if first <= sq <= last:
            sq_number.append(sq)
            continue
        if sq > last:
            break
    return sq_number


def process_user_input():
    """
    User inputs numbers until they want to stop by entering 0. It then lists the numbers, calculates the sum,
    finds the lowest number, the highest number
    :return: List of numbers , sum of the list, lowest number, highest number 
    """
    entry_list = []
    valid = True
    while valid:
        entry = int(input("Please enter a number or 0 to end:  "))
        if entry == 0:
            valid = False
        else:
            entry_list.append(entry)
    if not valid:
        print("Your numbers are:  ", entry_list)

    total = 0
    for i in entry_list:
        total += i
    print("Sum is:  ", total)

    lowest = entry_list[0]
    for low in entry_list:
        if low < lowest:
            lowest = low
    print("Min is:  ", lowest)

    highest = entry_list[0]
    for high in entry_list:
        if high > highest:
            highest = high
    print("Max is:  ", highest)


def main():

    print(get_square_numbers_between(30, 222))  # example 1
    print(get_square_numbers_between(500, 611))  # example 2
    print(process_user_input())


if __name__ == "__main__":
    main()
