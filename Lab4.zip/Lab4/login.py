# lab 4 login William Yu, Erik Lagman, Ethan Newton

def generate_password(first_name, last_name, bcit_id):
    """
    password generated from 3
    :param first_name: Name entered by user. Using only first 3 letters
    :param last_name: Last name entered by user. Using only first 3 letters
    :param bcit_id: id entered by user. Using only last 3 digits or letters
    :return: generated password from the three parameters combined
    """
    generated_password = (first_name.capitalize()[:3]) + (last_name.capitalize()[:3]) + (bcit_id[-3:])

    return generated_password


def change_password():
    """
    Getting the user to change the password from default one
    :return: New password made by the user
    """
    login_password = str(input("The password must be at least 7 characters long, one uppercase character,"
                         "one lower case character and one digit. Do not include special characters.""\n"
                               "Please enter a new password: "))
    while login_password:
        if not seven_char(login_password):
            login_password = str(input("Must have at least 7 characters.""\n"
                                       "Enter a new password. "))
        elif not up_char(login_password):
            login_password = str(input("Must have upper characters""\n"
                                       "Enter a new password. "))
        elif not one_num(login_password):
            login_password = str(input("Must have one number""\n"
                                       "Enter a new password."))
        elif not one_low(login_password):
            login_password = str(input("Must have one lower character""\n"
                                       "Enter a new password."))
        elif not special_char(login_password):
            login_password = str(input("May not have any special characters""\n"
                                       "Enter a new password."))
        else:
            print("Valid password")
            return login_password


def seven_char(login_password):
    """
    Makes sure the user has minimum 7 letters in the password
    :param login_password: checks if there is 7 characters in the password
    :return: 7 or more characters in the password
    """
    if len(login_password) >= 7:
        return True
    else:
        return False


def special_char(login_password):
    """
    Makes sure the user has no special characters
    :param login_password: checks there is no special characters
    :return: password with no special character
    """

    if login_password.isalnum():
        return True
    else:
        return False


def up_char(login_password):
    """
    Must have at least 1 upper case character within the password
    :param login_password: checks if there is one upper case letter
    :return: password with upper letter
    """
    index = 0
    while index < len(login_password):
        if login_password[index].isupper():
            return True
        index += 1
    else:
        return False


def one_num(login_password):
    """
    Must have at least 1 number in the password
    :param login_password: checks if there is at least 1 number
    :return: password with at least 1 number
    """
    index = 0
    while login_password:
        if login_password[index].isdigit():
            return True
        index += 1
    else:
        return False


def one_low(login_password):
    """
    Must have 1 lower case letter in the password
    :param login_password: checks if there is at least 1 lower case letter
    :return: password with at least 1 lower case letter
    """
    index = 0
    while login_password:
        if login_password[index].islower():
            return True
        index += 1
    else:
        return False
