# Lab 4 William Yu, Erik Lagman, Ethan Newton

import login

def main():

    first = input("Please enter your first name: ")  # user inputted first name
    last = input("Please enter your last name:  ")  # user inputted last name
    school_id = input("Please enter your BCIT ID:  ")  # users bcit id
    print("Your generated password is ", login.generate_password(first, last, school_id))  # generated password
    print("Your new password is:", login.change_password())  # password change by user


if __name__ == '__main__':
    main()
