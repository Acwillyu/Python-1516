# lab 4 Part 2 William Yu, Erik Lagman, Ethan Newton


def get_book_info():
    """
    book information entered by user
    :return: book information entered by user will show in one line with /
    """

    title = input("Please enter the book title:  ")
    book_isbn = input("Please enter the book isbn:  ")
    book_author_last_name = input("Please enter the author's last name:  ")
    book_publisher = input("Please enter the book publisher:  ")
    year_publish = input("Please enter the year the book was published:  ")
    book_price = float(input("Please enter the price of the book:  "))
    book_price_rounded = "{:.2f}".format(round(book_price, 2))
    book_information = [title.strip().title(), book_isbn, book_author_last_name.strip().title(),
                        book_publisher.strip().title(), year_publish, book_price_rounded]
    path = "/".join(book_information)
    return path


def to_csv_format(csv_printable):
    """
    converts book information to csv format
    :param csv_printable: prints the book information into csv format
    :return: csv formatted
    """
    book_information = csv_printable.split("/")
    csv_print = ",".join(book_information)
    return csv_print


def to_json_format(json_printable):
    """
    Converting the book information from csv format to json format
    :param json_printable: csv formatted book information to json format
    :return: converted csv format book information to json format
    """
    json_first = json_printable.find(",")
    json_book = json_printable[0:json_first]
    json_second = json_printable.find(",", json_first+1)
    json_isbn = json_printable[json_first+1: json_second]
    json_third = json_printable.find(",", json_second+1)
    json_last_name = json_printable[json_second+1:json_third]
    json_fourth = json_printable.find(",", json_third+1)
    json_publisher = json_printable[json_third+1:json_fourth]
    json_fifth = json_printable.find(",", json_fourth+1)
    json_year = json_printable[json_fourth+1:json_fifth]
    json_price = json_printable[json_fifth+1:]
    json_print = f'{{"title":"{json_book.strip().title()}",'  \
                 f'"Book isbn":"{json_isbn}",'   \
                 f'"Book author last name":"{json_last_name.strip().title()}",'   \
                 f'"Book publisher":"{json_publisher.strip().title()}",'\
                 f'"Year published":"{json_year}",'   \
                 f'"Book price":"{json_price}"}}'
    return json_print


def main():

    path = get_book_info()  # gets the book information from user
    print(path)  # book information combined with /
    print("The CSV Format String is:""\n",    # CSV format
          to_csv_format(path))
    print("The JSON Format String is:""\n",   # json format converted from csv format
          to_json_format(to_csv_format(path)))


if __name__ == '__main__':
    main()
